from fastapi import APIRouter, Depends, HTTPException
from app.schemas.auth import LoginRequest, TokenResponse
from app.core.security import create_access_token
from app.crud.user import authenticate_user
from app.db import get_db

router = APIRouter()

@router.post("/login", response_model=TokenResponse)
async def login(request: LoginRequest, db=Depends(get_db)):
    user = await authenticate_user(db, request.name, request.password)
    if not user:
        raise HTTPException(status_code=400, detail="Invalid credentials")
    token = create_access_token({"sub": user.name})
    return {"access_token": token, "token_type": "bearer"}
